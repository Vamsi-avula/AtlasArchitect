# Architect

See [here](../README.md) for build instructions.